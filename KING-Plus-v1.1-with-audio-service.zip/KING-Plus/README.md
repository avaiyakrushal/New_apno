# KING Plus Android v1.0 local build — local prototype

Open this folder in Android Studio with JDK 17 and Android SDK 35. The project uses Android Gradle Plugin 8.7.3. A Gradle wrapper is not included.

Working on one device: local name and profile picture, a generated device ID, text and gallery-photo posts, post timestamps, editing, removal, local likes and comments, Android share sheet, post and room search, user-created rooms with removal, microphone permission and sound-level test, and confirmed deletion of all local app data. Data is stored in app preferences; photo references are retained through Android's document picker. The ID is not an account ID.

Still required for a real multi-user social app: Google, Facebook and phone sign-in; a hosted identity service and database; cross-device post, profile and room synchronization; direct messages and notifications; real-time multi-user audio; moderation and abuse reporting; account deletion and server-side data handling. These cannot work by adding interface buttons alone. The local name screen must not be treated as authentication, and microphone testing does not transmit audio. Production integration needs the chosen backend project, authentication provider configuration, service credentials, and applicable app registration details.

This source package was checked as a ZIP but has not been compiled or run on a device in this environment, where Android SDK and Gradle are unavailable.

## APK build

The included `.github/workflows/android-debug.yml` builds a debug APK on a GitHub Actions runner when this project is placed at the repository root and pushed to `main` or `master`, or the workflow is run manually. Download `KING-Plus-debug-apk` from the completed run's Artifacts section. The APK is a debug build, not a signed production release. The workflow has not been run in this environment.

## Online integration inputs

To complete online accounts and social features, supply an owned backend project and configured Google/Facebook/phone sign-in providers; storage and database access rules; a real-time audio provider project; and production privacy/terms information. Keep credentials out of this source ZIP and configure them through the deployment environment. No online account or cross-device feature is implemented in this local prototype.

## Audio service project

`audio-service/` contains a separate Firebase-verified LiveKit token endpoint and its own setup instructions. It is not yet connected to the Android UI because this app has no Firebase sign-in or project configuration. The existing microphone meter remains a local-only test. The server keeps API secrets off the phone and issues 15-minute microphone-only grants.
