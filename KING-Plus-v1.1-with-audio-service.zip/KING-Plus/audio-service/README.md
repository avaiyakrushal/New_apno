# KING Plus voice token service

This service issues short-lived, microphone-only LiveKit room tokens after verifying a Firebase Authentication ID token. It never sends the LiveKit secret to the Android app. It is a server component, not a working audio room by itself.

## Setup

1. Create an owned Firebase project with Authentication configured and a LiveKit Cloud project, or deploy LiveKit on your own domain with TLS/TURN. Obtain the Firebase project ID, server application credentials, LiveKit URL, API key and API secret.
2. Install Node.js 20+, run `npm install` in this directory, and set the variables in `.env.example` in your server environment. Set `GOOGLE_APPLICATION_CREDENTIALS` to the private service-account JSON path (outside this repository), or use Application Default Credentials on your host.
3. Run `npm test`, then `npm start`. Put the service behind HTTPS and your server's reverse proxy. The default bind address is loopback, not public internet.
4. After the Android app has Firebase sign-in, call `POST /voice/token` with `Authorization: Bearer <Firebase ID token>` and JSON `{ "room": "stable_room_id", "name": "Display name" }`. The response gives `serverUrl` and `participantToken` for the LiveKit Android SDK. Use a stable room ID rather than a displayed room name.

This endpoint rejects requests without a verified Firebase ID token. It cannot be used by the current local-name prototype. Configure rate limits, account moderation, room authorization, HTTPS and operational monitoring before public launch. No live deployment or end-to-end audio test has been performed.
