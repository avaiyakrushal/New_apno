export function validRoom(value) {
  return typeof value === 'string' && /^[a-zA-Z0-9_-]{3,64}$/.test(value);
}

export function safeName(value) {
  return typeof value === 'string' ? value.trim().slice(0, 60) : '';
}
