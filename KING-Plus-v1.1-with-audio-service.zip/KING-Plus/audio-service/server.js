import http from 'node:http';
import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { AccessToken } from 'livekit-server-sdk';
import { validRoom, safeName } from './validation.js';

const { LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET, FIREBASE_PROJECT_ID } = process.env;
if (!LIVEKIT_URL || !LIVEKIT_API_KEY || !LIVEKIT_API_SECRET || !FIREBASE_PROJECT_ID) {
  throw new Error('LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET and FIREBASE_PROJECT_ID are required');
}
if (!/^wss:\/\//.test(LIVEKIT_URL) && !/^ws:\/\/(localhost|127\.0\.0\.1)(:\d+)?\/?$/.test(LIVEKIT_URL)) {
  throw new Error('Use wss:// for hosted LiveKit, or ws://localhost for local development');
}
initializeApp({ credential: applicationDefault(), projectId: FIREBASE_PROJECT_ID });
const port = Number(process.env.PORT || 8080);
const host = process.env.HOST || '127.0.0.1';

function json(res, status, value) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(value));
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') return json(res, 200, { status: 'ok' });
  if (req.method !== 'POST' || req.url !== '/voice/token') return json(res, 404, { error: 'not_found' });
  const authorization = req.headers.authorization || '';
  if (!authorization.startsWith('Bearer ') || authorization.length > 8192) return json(res, 401, { error: 'unauthorized' });
  try {
    let size = 0;
    const chunks = [];
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 4096) return json(res, 413, { error: 'too_large' });
      chunks.push(chunk);
    }
    const { room, name } = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!validRoom(room)) return json(res, 400, { error: 'invalid_room' });
    const firebaseToken = authorization.slice(7);
    const user = await getAuth().verifyIdToken(firebaseToken, true);
    const token = new AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET, {
      identity: user.uid,
      name: safeName(name) || safeName(user.name) || 'Member',
      ttl: '15m'
    });
    token.addGrant({
      roomJoin: true, room,
      canPublish: true, canSubscribe: true, canPublishData: false,
      canPublishSources: ['microphone']
    });
    return json(res, 200, { serverUrl: LIVEKIT_URL, participantToken: await token.toJwt() });
  } catch (error) {
    if (error instanceof SyntaxError) return json(res, 400, { error: 'invalid_json' });
    if (String(error?.code || '').startsWith('auth/')) return json(res, 401, { error: 'unauthorized' });
    console.error('Token request failed', error);
    return json(res, 500, { error: 'server_error' });
  }
});
server.listen(port, host, () => console.log(`Audio token service listening on ${host}:${port}`));
