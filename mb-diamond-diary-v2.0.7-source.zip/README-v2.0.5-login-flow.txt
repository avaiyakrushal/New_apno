MB Diamond Diary — Login/Company flow update

Existing diamond/hour/expense/report/settings app logic remains unchanged.
Updated login/company onboarding only:
- Google-only login.
- Choose Worker or Boss after first login.
- Worker profile: first name, surname, mobile, birthday.
- Boss creates company and receives a unique 6-character alphanumeric code (example: LBCEQ5).
- Boss can share the company name + code through WhatsApp or Android share sheet.
- Worker enters the boss's 6-character code and sends a join request.
- Boss sees worker name, mobile, birthday and worker-entered total diamonds.
- Boss can approve work type, mark inactive, or remove worker.
- Existing app opens after approval.
