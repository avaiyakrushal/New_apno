MB Diamond Diary v2.0.6 — Admin Dashboard

Added owner-only Admin Dashboard.

Admin can see:
- Total users
- Total bosses
- Total workers
- Total companies
- Active workers
- Pending workers
- Workers without a company
- Each company name, company code, and worker count

Security model:
- Normal boss can only see/manage their own company.
- Normal worker can only see/join their own company flow.
- Admin access is enabled only when Firestore has document:
    admins/{ADMIN_FIREBASE_UID}
  with field:
    enabled = true

The app checks admins/{uid} immediately after Google login.
If enabled=true, Admin Dashboard opens instead of normal boss/worker routing.

IMPORTANT:
Deploy firestore.rules included in this source. The admin document must be created manually from Firebase Console (or a trusted server); app users cannot create admin privileges themselves.
