# MB Diamond Diary 2.0.1 source (work in progress)

The native Activity uses Firebase Google sign-in (Credential Manager), sign-out, and a Firestore worker approval listener. Unapproved workers see their UID and cannot open the diary. Approved workers see only their assigned diamond or hour entry and report tab. An admin/owner can enter a worker UID and assign a work mode. Local records are isolated by Firebase UID; the first signed-in account on a phone receives the previous offline v2 records.

This is source code, not a tested APK. Before distributing an APK, use a stable signing key, register SHA-1 and SHA-256 for `com.example.diamonddiary`, download refreshed `google-services.json`, build and test on an Android device. Installing an APK with a new debug signing certificate may require uninstalling an earlier build and may lose its local data.

The `firestore.rules` draft currently identifies `maniyaj786@gmail.com` as the bootstrap admin/owner. The rules must be published in Firebase before worker approvals work. The worker management code depends on those rules. Worker records, notifications and diamond/hour entries are not cloud-synced yet; they are local to each phone. The notifications tab is a visual mockup, not a working messaging system.
