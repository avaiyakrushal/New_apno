MB Diamond Diary v2.0.7 — Final Login / Company Flow

Based on the actual MB Diamond Diary app family.

Kept unchanged:
- Diamond entry/list/detail and A-G rates
- Hour entry/list/report
- Expense/withdrawal
- Monthly/combined/expense reports and PDF flow
- Photo upload, notifications and settings

Login/company updates:
- Google-only login
- One-time role choice: Worker or Boss
- Worker profile: first name, surname, mobile, birthday
- Boss creates company and receives 6-character code
- Code sharing via WhatsApp/system share
- Worker joins with company code and waits for approval
- Boss approves worker once; approved workers get the full existing diary app (diamond + hours)
- Boss worker list shows name, mobile, birthday and worker-entered total diamonds
- Inactive/remove preserve worker history; remove no longer hard-deletes the worker record
- Admin dashboard remains owner-only through admins/{uid}.enabled=true
