package com.example.diamonddiary;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;
import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView page;
    private WebView printing;
    private ValueCallback<Uri[]> chooserCallback;
    private static final int FILE_CHOOSE = 93;

    private FirebaseAuth auth;
    private FirebaseFirestore database;
    private CredentialManager credentials;

    private LinearLayout login;
    private Button loginButton;
    private TextView loginStatus;

    private LinearLayout roleChoice;
    private LinearLayout workerProfile;
    private EditText profileFirstName;
    private EditText profileLastName;
    private EditText profilePhone;
    private EditText profileBirthday;
    private Button workerProfileSave;

    private LinearLayout bossScreen;
    private LinearLayout bossCreateBox;
    private LinearLayout bossInfoBox;
    private EditText bossCompanyInput;
    private TextView bossCompanyName;
    private TextView bossCompanyCode;
    private TextView bossWorkersTitle;
    private LinearLayout bossWorkers;
    private Button createCompanyButton;

    private LinearLayout workerJoin;
    private EditText workerCodeInput;
    private TextView workerJoinStatus;
    private Button workerJoinButton;

    private LinearLayout pending;
    private TextView pendingInfo;

    private LinearLayout adminScreen;
    private TextView adminStats;
    private LinearLayout adminCompanies;

    private boolean signingIn;
    private String loadedUid;
    private String currentRole;
    private String currentMode;
    private String currentCompanyName;
    private String currentCompanyCode;
    private boolean bossAppOpened;

    private ListenerRegistration workerListener;
    private ListenerRegistration bossWorkersListener;
    private String watchingUid;

    private static final SecureRandom RANDOM = new SecureRandom();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        auth = FirebaseAuth.getInstance();
        database = FirebaseFirestore.getInstance();
        credentials = CredentialManager.create(this);

        getWindow().setStatusBarColor(0xff17243a);
        getWindow().setNavigationBarColor(0xffffffff);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        FrameLayout root = new FrameLayout(this);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }

        page = new WebView(this);
        page.getSettings().setJavaScriptEnabled(true);
        page.getSettings().setDomStorageEnabled(true);
        page.getSettings().setAllowFileAccess(true);
        page.addJavascriptInterface(new Bridge(), "Android");
        page.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                updateAccountLabel();
                updateRoleInPage();
            }
        });
        page.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_CHOOSE);
                    return true;
                } catch (Exception e) {
                    chooserCallback = null;
                    return false;
                }
            }
        });
        root.addView(page, new FrameLayout.LayoutParams(-1, -1));

        createLoginScreen(root);
        createRoleChoiceScreen(root);
        createWorkerProfileScreen(root);
        createBossScreen(root);
        createWorkerJoinScreen(root);
        createPendingScreen(root);
        createAdminScreen(root);

        setContentView(root);
        showAuthState();
    }

    private void createLoginScreen(FrameLayout root) {
        login = baseScreen();
        TextView title = titleText("◆  MB ડાયમંડ ડાયરી");
        login.addView(title, fullWrap());

        TextView subtitle = bodyText("તમારા Google એકાઉન્ટથી લોગીન કરો");
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(18), 0, dp(18));
        login.addView(subtitle, fullWrap());

        loginButton = primaryButton("Google સાથે લોગીન કરો");
        loginButton.setOnClickListener(v -> signIn());
        login.addView(loginButton, fullWrap());

        loginStatus = bodyText("");
        loginStatus.setGravity(Gravity.CENTER);
        loginStatus.setPadding(0, dp(12), 0, 0);
        login.addView(loginStatus, fullWrap());
        root.addView(login, new FrameLayout.LayoutParams(-1, -1));
    }

    private void createRoleChoiceScreen(FrameLayout root) {
        roleChoice = baseScreen();
        roleChoice.addView(titleText("◆  MB ડાયમંડ ડાયરી"), fullWrap());
        TextView title = sectionText("તમે કોણ છો?");
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(18), 0, dp(10));
        roleChoice.addView(title, fullWrap());
        TextView note = bodyText("આ પસંદગી પછીથી બદલી શકાશે નહીં.");
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, 0, 0, dp(18));
        roleChoice.addView(note, fullWrap());

        Button worker = primaryButton("હું કારીગર છું");
        worker.setOnClickListener(v -> saveRole("worker"));
        roleChoice.addView(worker, fullWrap());
        Button boss = secondaryButton("હું શેઠ (માલિક) છું");
        boss.setOnClickListener(v -> saveRole("boss"));
        roleChoice.addView(boss, fullWrap());

        Button logout = secondaryButton("લોગ આઉટ");
        logout.setOnClickListener(v -> signOut());
        roleChoice.addView(logout, fullWrap());
        root.addView(roleChoice, new FrameLayout.LayoutParams(-1, -1));
        roleChoice.setVisibility(View.GONE);
    }

    private void createWorkerProfileScreen(FrameLayout root) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        workerProfile = baseScreen();
        workerProfile.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        scroll.addView(workerProfile, new ScrollView.LayoutParams(-1, -2));
        workerProfile.addView(titleText("◆  MB ડાયમંડ ડાયરી"), fullWrap());
        TextView title = sectionText("કારીગરની માહિતી");
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(14), 0, dp(6));
        workerProfile.addView(title, fullWrap());
        TextView note = bodyText("આ માહિતી તમારા શેઠના કારીગર લિસ્ટમાં દેખાશે.");
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, 0, 0, dp(12));
        workerProfile.addView(note, fullWrap());

        profileFirstName = input("નામ");
        profileLastName = input("સરનેમ");
        profilePhone = input("મોબાઇલ નંબર");
        profileBirthday = input("જન્મ તારીખ (YYYY-MM-DD)");
        workerProfile.addView(profileFirstName, fullWrap());
        workerProfile.addView(profileLastName, fullWrap());
        workerProfile.addView(profilePhone, fullWrap());
        workerProfile.addView(profileBirthday, fullWrap());
        workerProfileSave = primaryButton("માહિતી સેવ કરો");
        workerProfileSave.setOnClickListener(v -> saveWorkerProfile());
        workerProfile.addView(workerProfileSave, fullWrap());
        Button logout = secondaryButton("લોગ આઉટ");
        logout.setOnClickListener(v -> signOut());
        workerProfile.addView(logout, fullWrap());

        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        workerProfile.setTag(scroll);
        scroll.setVisibility(View.GONE);
    }

    private void createBossScreen(FrameLayout root) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        bossScreen = baseScreen();
        bossScreen.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        scroll.addView(bossScreen, new ScrollView.LayoutParams(-1, -2));

        bossScreen.addView(titleText("◆  MB ડાયમંડ ડાયરી"), fullWrap());
        TextView role = bodyText("શેઠ લોગીન");
        role.setGravity(Gravity.CENTER);
        role.setPadding(0, dp(8), 0, dp(20));
        bossScreen.addView(role, fullWrap());

        bossCreateBox = new LinearLayout(this);
        bossCreateBox.setOrientation(LinearLayout.VERTICAL);
        bossCreateBox.setPadding(dp(16), dp(16), dp(16), dp(16));
        TextView createTitle = sectionText("તમારી કંપનીનું નામ લખો");
        bossCreateBox.addView(createTitle, fullWrap());
        bossCompanyInput = input("જેમ કે MB Diamond");
        bossCreateBox.addView(bossCompanyInput, fullWrap());
        createCompanyButton = primaryButton("કંપની બનાવો");
        createCompanyButton.setOnClickListener(v -> createCompany());
        bossCreateBox.addView(createCompanyButton, fullWrap());
        bossScreen.addView(bossCreateBox, fullWrap());

        bossInfoBox = new LinearLayout(this);
        bossInfoBox.setOrientation(LinearLayout.VERTICAL);
        bossInfoBox.setPadding(dp(16), dp(12), dp(16), dp(16));
        bossCompanyName = sectionText("");
        bossCompanyName.setGravity(Gravity.CENTER);
        bossInfoBox.addView(bossCompanyName, fullWrap());
        TextView codeLabel = bodyText("કંપની કોડ");
        codeLabel.setGravity(Gravity.CENTER);
        codeLabel.setPadding(0, dp(10), 0, dp(4));
        bossInfoBox.addView(codeLabel, fullWrap());
        bossCompanyCode = titleText("");
        bossCompanyCode.setTextSize(30);
        bossInfoBox.addView(bossCompanyCode, fullWrap());

        Button share = primaryButton("કોડ શેર કરો");
        share.setOnClickListener(v -> shareCompany());
        bossInfoBox.addView(share, fullWrap());

        Button open = secondaryButton("એપ ખોલો");
        open.setOnClickListener(v -> {
            FirebaseUser user = auth.getCurrentUser();
            if (user == null) return;
            bossAppOpened = true;
            grantRole(user, "boss", "both");
        });
        bossInfoBox.addView(open, fullWrap());

        bossWorkersTitle = sectionText("કારીગરો");
        bossWorkersTitle.setPadding(0, dp(22), 0, dp(8));
        bossInfoBox.addView(bossWorkersTitle, fullWrap());
        bossWorkers = new LinearLayout(this);
        bossWorkers.setOrientation(LinearLayout.VERTICAL);
        bossInfoBox.addView(bossWorkers, fullWrap());

        Button logout = secondaryButton("લોગ આઉટ");
        logout.setOnClickListener(v -> signOut());
        bossInfoBox.addView(logout, fullWrap());

        bossScreen.addView(bossInfoBox, fullWrap());
        bossInfoBox.setVisibility(View.GONE);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        bossScreen.setTag(scroll);
        scroll.setVisibility(View.GONE);
    }

    private void createWorkerJoinScreen(FrameLayout root) {
        workerJoin = baseScreen();
        workerJoin.addView(titleText("◆  MB ડાયમંડ ડાયરી"), fullWrap());
        TextView workerTitle = sectionText("કારીગર લોગીન");
        workerTitle.setGravity(Gravity.CENTER);
        workerTitle.setPadding(0, dp(12), 0, dp(6));
        workerJoin.addView(workerTitle, fullWrap());
        TextView hint = bodyText("તમારા શેઠ પાસેથી 6 અક્ષરનો કોડ લઈને અહીં નાખો.");
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 0, 0, dp(16));
        workerJoin.addView(hint, fullWrap());

        workerCodeInput = input("શેઠનો કોડ");
        workerCodeInput.setGravity(Gravity.CENTER);
        workerJoin.addView(workerCodeInput, fullWrap());
        workerJoinButton = primaryButton("રિક્વેસ્ટ મોકલો");
        workerJoinButton.setOnClickListener(v -> joinCompany());
        workerJoin.addView(workerJoinButton, fullWrap());
        workerJoinStatus = bodyText("");
        workerJoinStatus.setGravity(Gravity.CENTER);
        workerJoinStatus.setPadding(0, dp(12), 0, 0);
        workerJoin.addView(workerJoinStatus, fullWrap());
        Button logout = secondaryButton("લોગ આઉટ");
        logout.setOnClickListener(v -> signOut());
        workerJoin.addView(logout, fullWrap());
        root.addView(workerJoin, new FrameLayout.LayoutParams(-1, -1));
        workerJoin.setVisibility(View.GONE);
    }

    private void createPendingScreen(FrameLayout root) {
        pending = baseScreen();
        pending.addView(titleText("◆  MB ડાયમંડ ડાયરી"), fullWrap());
        TextView waitingTitle = sectionText("કારીગર લોગીન");
        waitingTitle.setGravity(Gravity.CENTER);
        waitingTitle.setPadding(0, dp(12), 0, dp(8));
        pending.addView(waitingTitle, fullWrap());
        pendingInfo = bodyText("");
        pendingInfo.setGravity(Gravity.CENTER);
        pendingInfo.setPadding(0, dp(8), 0, dp(16));
        pending.addView(pendingInfo, fullWrap());
        Button retry = secondaryButton("ફરી તપાસો");
        retry.setOnClickListener(v -> { clearWorkerListener(); showAuthState(); });
        pending.addView(retry, fullWrap());
        Button pendingSignOut = secondaryButton("લોગ આઉટ");
        pendingSignOut.setOnClickListener(v -> signOut());
        pending.addView(pendingSignOut, fullWrap());
        root.addView(pending, new FrameLayout.LayoutParams(-1, -1));
        pending.setVisibility(View.GONE);
        setAdminVisible(false);
    }


    private void createAdminScreen(FrameLayout root) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        adminScreen = baseScreen();
        adminScreen.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        scroll.addView(adminScreen, new ScrollView.LayoutParams(-1, -2));

        adminScreen.addView(titleText("◆  MB ડાયમંડ ડાયરી"), fullWrap());
        TextView title = sectionText("Admin Dashboard");
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(10), 0, dp(12));
        adminScreen.addView(title, fullWrap());

        adminStats = bodyText("ડેટા લોડ થઈ રહ્યો છે…");
        adminStats.setTextSize(17);
        adminStats.setPadding(dp(12), dp(12), dp(12), dp(12));
        adminScreen.addView(adminStats, fullWrap());

        TextView companyTitle = sectionText("કંપની પ્રમાણે યુઝર");
        companyTitle.setPadding(0, dp(18), 0, dp(8));
        adminScreen.addView(companyTitle, fullWrap());

        adminCompanies = new LinearLayout(this);
        adminCompanies.setOrientation(LinearLayout.VERTICAL);
        adminScreen.addView(adminCompanies, fullWrap());

        Button refresh = primaryButton("રીફ્રેશ કરો");
        refresh.setOnClickListener(v -> loadAdminDashboard());
        adminScreen.addView(refresh, fullWrap());

        Button logout = secondaryButton("લોગ આઉટ");
        logout.setOnClickListener(v -> signOut());
        adminScreen.addView(logout, fullWrap());

        adminScreen.setTag(scroll);
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        scroll.setVisibility(View.GONE);
    }

    private void setAdminVisible(boolean visible) {
        if (adminScreen == null) return;
        Object tag = adminScreen.getTag();
        if (tag instanceof ScrollView) ((ScrollView) tag).setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    private void showAdminDashboard() {
        currentRole = "admin";
        clearWorkerListener();
        clearBossWorkersListener();
        hideAll();
        setAdminVisible(true);
        loadAdminDashboard();
    }

    private void loadAdminDashboard() {
        if (adminStats == null || adminCompanies == null) return;
        adminStats.setText("ડેટા લોડ થઈ રહ્યો છે…");
        adminCompanies.removeAllViews();

        database.collection("users").get().addOnSuccessListener(usersSnap -> {
            database.collection("companies").get().addOnSuccessListener(companiesSnap -> {
                database.collection("workers").get().addOnSuccessListener(workersSnap -> {
                    int totalUsers = usersSnap.size();
                    int bosses = 0;
                    int workers = 0;
                    Set<String> workerUserIds = new HashSet<>();
                    for (DocumentSnapshot userDoc : usersSnap.getDocuments()) {
                        String role = safe(userDoc.getString("role"));
                        if ("boss".equals(role)) bosses++;
                        if ("worker".equals(role)) {
                            workers++;
                            workerUserIds.add(userDoc.getId());
                        }
                    }

                    int active = 0;
                    int pendingCount = 0;
                    Set<String> linkedWorkerIds = new HashSet<>();
                    Map<String, Integer> companyWorkerCount = new HashMap<>();
                    for (DocumentSnapshot workerDoc : workersSnap.getDocuments()) {
                        linkedWorkerIds.add(workerDoc.getId());
                        if (Boolean.TRUE.equals(workerDoc.getBoolean("active"))) active++;
                        else pendingCount++;
                        String companyId = safe(workerDoc.getString("companyId"));
                        if (companyId.length() > 0)
                            companyWorkerCount.put(companyId, companyWorkerCount.getOrDefault(companyId, 0) + 1);
                    }

                    int withoutCompany = 0;
                    for (String uid : workerUserIds) if (!linkedWorkerIds.contains(uid)) withoutCompany++;

                    adminStats.setText(
                        "કુલ યુઝર: " + totalUsers +
                        "\nકુલ શેઠ: " + bosses +
                        "\nકુલ કારીગર: " + workers +
                        "\nકુલ કંપની: " + companiesSnap.size() +
                        "\nActive કારીગર: " + active +
                        "\nPending કારીગર: " + pendingCount +
                        "\nકંપની વગરના કારીગર: " + withoutCompany
                    );

                    if (companiesSnap.isEmpty()) {
                        adminCompanies.addView(bodyText("હજુ કોઈ કંપની નથી."), fullWrap());
                    } else {
                        for (DocumentSnapshot companyDoc : companiesSnap.getDocuments()) {
                            String name = safe(companyDoc.getString("name"));
                            String code = safe(companyDoc.getString("code"));
                            int count = companyWorkerCount.getOrDefault(companyDoc.getId(), 0);
                            TextView row = bodyText((name.length() == 0 ? "કંપની" : name) +
                                (code.length() == 0 ? "" : "  •  " + code) +
                                "\nકારીગર: " + count);
                            row.setPadding(dp(14), dp(12), dp(14), dp(12));
                            adminCompanies.addView(row, fullWrap());
                        }
                    }
                }).addOnFailureListener(e -> adminStats.setText("Workers ડેટા લોડ થઈ શક્યો નથી."));
            }).addOnFailureListener(e -> adminStats.setText("Companies ડેટા લોડ થઈ શક્યો નથી."));
        }).addOnFailureListener(e -> adminStats.setText("Users ડેટા લોડ થઈ શક્યો નથી."));
    }

    @Override protected void onStart() {
        super.onStart();
        if (auth != null) showAuthState();
    }

    private void showAuthState() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            clearWorkerListener();
            clearBossWorkersListener();
            currentRole = null;
            currentMode = null;
            currentCompanyName = null;
            currentCompanyCode = null;
            bossAppOpened = false;
            hideAll();
            login.setVisibility(View.VISIBLE);
            if (loadedUid != null) {
                loadedUid = null;
                page.loadUrl("about:blank");
            }
            return;
        }
        login.setVisibility(View.GONE);
        routeSignedInUser(user);
    }

    private void routeSignedInUser(FirebaseUser user) {
        hideAll();
        database.collection("admins").document(user.getUid()).get()
            .addOnSuccessListener(adminDoc -> {
                if (adminDoc.exists() && Boolean.TRUE.equals(adminDoc.getBoolean("enabled"))) {
                    showAdminDashboard();
                    return;
                }
                routeRegularUser(user);
            })
            .addOnFailureListener(e -> routeRegularUser(user));
    }

    private void routeRegularUser(FirebaseUser user) {
        database.collection("users").document(user.getUid()).get()
            .addOnSuccessListener(snapshot -> {
                FirebaseUser active = auth.getCurrentUser();
                if (active == null || !user.getUid().equals(active.getUid())) return;
                String role = safe(snapshot.getString("role"));
                if ("boss".equals(role)) {
                    currentRole = "boss";
                    clearWorkerListener();
                    showBossCompany(user);
                } else if ("worker".equals(role)) {
                    currentRole = "worker";
                    clearBossWorkersListener();
                    String first = safe(snapshot.getString("firstName"));
                    String last = safe(snapshot.getString("lastName"));
                    String phone = safe(snapshot.getString("phone"));
                    String birthday = safe(snapshot.getString("birthday"));
                    if (first.length() == 0 || phone.length() == 0 || birthday.length() == 0) {
                        showWorkerProfile(user, snapshot);
                    } else {
                        showWorkerState(user);
                    }
                } else {
                    showRoleChoice();
                }
            })
            .addOnFailureListener(e -> showRoleChoice());
    }

    private void showRoleChoice() {
        hideAll();
        roleChoice.setVisibility(View.VISIBLE);
    }

    private void saveRole(String role) {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null || !("boss".equals(role) || "worker".equals(role))) return;
        Map<String,Object> data = new HashMap<>();
        data.put("role", role);
        data.put("email", safe(user.getEmail()));
        data.put("googleName", safe(user.getDisplayName()));
        database.collection("users").document(user.getUid()).set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnSuccessListener(v -> routeSignedInUser(user));
    }

    private void showWorkerProfile(FirebaseUser user, DocumentSnapshot snapshot) {
        hideAll();
        Object tag = workerProfile.getTag();
        if (tag instanceof ScrollView) ((ScrollView) tag).setVisibility(View.VISIBLE);
        String first = safe(snapshot.getString("firstName"));
        String last = safe(snapshot.getString("lastName"));
        if (first.length() == 0) {
            String google = safe(user.getDisplayName());
            if (google.length() > 0) {
                String[] parts = google.split("\\s+", 2);
                first = parts[0];
                if (parts.length > 1) last = parts[1];
            }
        }
        profileFirstName.setText(first);
        profileLastName.setText(last);
        profilePhone.setText(safe(snapshot.getString("phone")));
        profileBirthday.setText(safe(snapshot.getString("birthday")));
        workerProfileSave.setEnabled(true);
    }

    private void saveWorkerProfile() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;
        String first = profileFirstName.getText().toString().trim();
        String last = profileLastName.getText().toString().trim();
        String phone = profilePhone.getText().toString().replaceAll("[^0-9]", "");
        String birthday = profileBirthday.getText().toString().trim();
        if (first.length() < 2) { profileFirstName.setError("નામ લખો"); return; }
        if (phone.length() != 10) { profilePhone.setError("10 અંકનો મોબાઇલ નંબર લખો"); return; }
        if (!birthday.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) { profileBirthday.setError("જન્મ તારીખ YYYY-MM-DD માં લખો"); return; }
        Map<String,Object> data = new HashMap<>();
        data.put("role", "worker");
        data.put("firstName", first);
        data.put("lastName", last);
        data.put("name", (first + " " + last).trim());
        data.put("phone", phone);
        data.put("birthday", birthday);
        data.put("email", safe(user.getEmail()));
        workerProfileSave.setEnabled(false);
        database.collection("users").document(user.getUid()).set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnSuccessListener(v -> { workerProfileSave.setEnabled(true); showWorkerState(user); })
            .addOnFailureListener(e -> { workerProfileSave.setEnabled(true); profileFirstName.setError("માહિતી સેવ થઈ નથી"); });
    }

    private void showBossCompany(FirebaseUser user) {
        currentRole = "boss";
        hideAll();
        setBossVisible(true);
        bossCreateBox.setVisibility(View.GONE);
        bossInfoBox.setVisibility(View.GONE);

        database.collection("companies").document(user.getUid()).get()
            .addOnSuccessListener(snapshot -> {
                if (auth.getCurrentUser() == null || !user.getUid().equals(auth.getCurrentUser().getUid())) return;
                if (snapshot.exists()) {
                    currentCompanyName = safe(snapshot.getString("name"));
                    currentCompanyCode = safe(snapshot.getString("code"));
                    showBossCompanyInfo(user);
                } else {
                    bossCreateBox.setVisibility(View.VISIBLE);
                    bossInfoBox.setVisibility(View.GONE);
                }
            })
            .addOnFailureListener(e -> {
                bossCreateBox.setVisibility(View.VISIBLE);
                createCompanyButton.setEnabled(true);
            });
    }

    private void showBossCompanyInfo(FirebaseUser user) {
        bossCreateBox.setVisibility(View.GONE);
        bossInfoBox.setVisibility(View.VISIBLE);
        bossCompanyName.setText(currentCompanyName.length() == 0 ? "તમારી કંપની" : currentCompanyName);
        bossCompanyCode.setText(currentCompanyCode);
        watchPendingWorkers(user.getUid());
    }

    private void createCompany() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null || !"boss".equals(currentRole)) return;
        String name = bossCompanyInput.getText().toString().trim();
        if (name.length() < 2) {
            bossCompanyInput.setError("કંપનીનું નામ લખો");
            return;
        }
        if (name.length() > 80) name = name.substring(0, 80);
        createCompanyButton.setEnabled(false);
        createCompanyWithFreshCode(user, name, 0);
    }

    private void createCompanyWithFreshCode(FirebaseUser user, String name, int attempt) {
        if (attempt >= 6) {
            createCompanyButton.setEnabled(true);
            bossCompanyInput.setError("કોડ બનાવી શકાયો નથી. ફરી પ્રયાસ કરો.");
            return;
        }
        String alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        StringBuilder codeBuilder = new StringBuilder(6);
        for (int i = 0; i < 6; i++) codeBuilder.append(alphabet.charAt(RANDOM.nextInt(alphabet.length())));
        String code = codeBuilder.toString();
        DocumentReference codeRef = database.collection("companyCodes").document(code);
        codeRef.get().addOnSuccessListener(codeSnapshot -> {
            if (codeSnapshot.exists()) {
                createCompanyWithFreshCode(user, name, attempt + 1);
                return;
            }
            Map<String, Object> company = new HashMap<>();
            company.put("name", name);
            company.put("code", code);
            company.put("bossUid", user.getUid());

            Map<String, Object> codeData = new HashMap<>();
            codeData.put("companyId", user.getUid());
            codeData.put("companyName", name);

            com.google.firebase.firestore.WriteBatch batch = database.batch();
            batch.set(database.collection("companies").document(user.getUid()), company);
            batch.set(codeRef, codeData);
            batch.commit()
                .addOnSuccessListener(v -> {
                    createCompanyButton.setEnabled(true);
                    currentCompanyName = name;
                    currentCompanyCode = code;
                    showBossCompanyInfo(user);
                })
                .addOnFailureListener(e -> {
                    createCompanyButton.setEnabled(true);
                    bossCompanyInput.setError("કંપની સેવ થઈ નથી. ફરી પ્રયાસ કરો.");
                });
        }).addOnFailureListener(e -> {
            createCompanyButton.setEnabled(true);
            bossCompanyInput.setError("કોડ ચેક થઈ શક્યો નથી. ફરી પ્રયાસ કરો.");
        });
    }

    private void shareCompany() {
        if (currentCompanyName == null || currentCompanyCode == null) return;
        String text = "MB Diamond Diary\nકંપની: " + currentCompanyName + "\nકંપની કોડ: " + currentCompanyCode;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, text);
        send.setPackage("com.whatsapp");
        try {
            startActivity(send);
        } catch (ActivityNotFoundException e) {
            Intent fallback = new Intent(Intent.ACTION_SEND);
            fallback.setType("text/plain");
            fallback.putExtra(Intent.EXTRA_TEXT, text);
            startActivity(Intent.createChooser(fallback, "કંપની નામ + કોડ શેર કરો"));
        }
    }

    private void watchPendingWorkers(String companyId) {
        clearBossWorkersListener();
        bossWorkersListener = database.collection("workers")
            .whereEqualTo("companyId", companyId)
            .addSnapshotListener((snapshots, error) -> {
                if (error != null || snapshots == null) return;
                bossWorkers.removeAllViews();
                int total = snapshots.size();
                for (DocumentSnapshot worker : snapshots.getDocuments()) addWorkerRow(worker);
                bossWorkersTitle.setText(total == 0 ? "હજુ કોઈ કારીગર જોડાયેલો નથી" : "કારીગરો · " + total);
            });
    }

    private void addWorkerRow(DocumentSnapshot worker) {
        String workerId = worker.getId();
        String nameText = safe(worker.getString("name"));
        if (nameText.length() == 0) nameText = "કારીગર";
        String phone = safe(worker.getString("phone"));
        String birthday = safe(worker.getString("birthday"));
        Long totalDiamondsValue = worker.getLong("totalDiamonds");
        long totalDiamonds = totalDiamondsValue == null ? 0 : totalDiamondsValue;
        boolean active = Boolean.TRUE.equals(worker.getBoolean("active"));
        boolean removed = Boolean.TRUE.equals(worker.getBoolean("removed"));
        if (removed) return;

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));

        TextView name = sectionText(nameText);
        name.setGravity(Gravity.START);
        card.addView(name, fullWrap());
        card.addView(bodyText("મોબાઇલ: " + (phone.length() == 0 ? "—" : phone)), fullWrap());
        card.addView(bodyText("જન્મ તારીખ: " + (birthday.length() == 0 ? "—" : birthday)), fullWrap());
        card.addView(bodyText("કારીગરના લખેલા કુલ હીરા: " + totalDiamonds), fullWrap());
        card.addView(bodyText(active ? "સ્થિતિ: ચાલુ" : "સ્થિતિ: મંજૂરી બાકી"), fullWrap());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(8), 0, dp(4));
        if (!active) {
            Button approve = primaryButton("મંજૂર કરો");
            approve.setOnClickListener(v -> approveWorker(workerId));
            actions.addView(approve, new LinearLayout.LayoutParams(0, -2, 1f));
        } else {
            Button inactive = secondaryButton("Inactive");
            inactive.setOnClickListener(v -> setWorkerInactive(workerId));
            actions.addView(inactive, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        Button remove = secondaryButton("દૂર કરો");
        remove.setOnClickListener(v -> removeWorker(workerId));
        actions.addView(remove, new LinearLayout.LayoutParams(0, -2, 1f));
        card.addView(actions, fullWrap());
        bossWorkers.addView(card, fullWrap());
    }

    private void approveWorker(String workerId) {
        Map<String, Object> update = new HashMap<>();
        update.put("mode", "both");
        update.put("active", true);
        update.put("removed", false);
        database.collection("workers").document(workerId).update(update);
    }

    private void setWorkerInactive(String workerId) {
        Map<String,Object> update = new HashMap<>();
        update.put("active", false);
        database.collection("workers").document(workerId).update(update);
    }

    private void removeWorker(String workerId) {
        Map<String,Object> update = new HashMap<>();
        update.put("active", false);
        update.put("removed", true);
        update.put("removedAt", com.google.firebase.firestore.FieldValue.serverTimestamp());
        database.collection("workers").document(workerId).update(update);
    }

    private void showWorkerState(FirebaseUser user) {
        if (user.getUid().equals(watchingUid) && workerListener != null) {
            if ("worker".equals(currentRole) && "both".equals(currentMode))
                grantRole(user, "worker", "both");
            return;
        }
        hideAll();
        page.setVisibility(View.GONE);

        clearWorkerListener();
        watchingUid = user.getUid();
        workerListener = database.collection("workers").document(watchingUid)
            .addSnapshotListener((snapshot, error) -> {
                FirebaseUser active = auth.getCurrentUser();
                if (active == null || watchingUid == null || !watchingUid.equals(active.getUid())) return;
                if (error != null) {
                    showWorkerJoin();
                    workerJoinStatus.setText("કોડ તપાસવામાં ભૂલ. ફરી પ્રયાસ કરો.");
                    return;
                }
                if (snapshot == null || !snapshot.exists()) {
                    showWorkerJoin();
                    return;
                }
                currentCompanyName = safe(snapshot.getString("companyName"));
                boolean removed = Boolean.TRUE.equals(snapshot.getBoolean("removed"));
                if (removed) {
                    showWorkerJoin();
                    workerJoinStatus.setText("તમને કંપનીમાંથી દૂર કરવામાં આવ્યા છે. નવો કોડ નાખીને ફરી જોડાઈ શકો છો.");
                } else if (Boolean.TRUE.equals(snapshot.getBoolean("active"))) {
                    grantRole(active, "worker", "both");
                } else {
                    showWorkerPending(currentCompanyName);
                }
            });
    }

    private void showWorkerJoin() {
        hideAll();
        workerJoin.setVisibility(View.VISIBLE);
        workerJoinButton.setEnabled(true);
        if (workerJoinStatus != null) workerJoinStatus.setText("");
    }

    private void joinCompany() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;
        String code = workerCodeInput.getText().toString().trim().toUpperCase(java.util.Locale.US);
        if (!code.matches("[A-Z0-9]{6}")) {
            workerCodeInput.setError("6 અક્ષરનો શેઠનો કોડ લખો");
            return;
        }
        workerJoinButton.setEnabled(false);
        workerJoinStatus.setText("રિક્વેસ્ટ મોકલાઈ રહી છે…");
        database.collection("companyCodes").document(code).get()
            .addOnSuccessListener(snapshot -> {
                if (!snapshot.exists()) {
                    workerJoinButton.setEnabled(true);
                    workerJoinStatus.setText("આ શેઠનો કોડ મળ્યો નથી");
                    return;
                }
                String companyId = safe(snapshot.getString("companyId"));
                String companyName = safe(snapshot.getString("companyName"));
                if (companyId.length() == 0 || companyName.length() == 0) {
                    workerJoinButton.setEnabled(true);
                    workerJoinStatus.setText("આ શેઠનો કોડ માન્ય નથી");
                    return;
                }
                database.collection("users").document(user.getUid()).get().addOnSuccessListener(profile -> {
                    String first = safe(profile.getString("firstName"));
                    String last = safe(profile.getString("lastName"));
                    String displayName = (first + " " + last).trim();
                    if (displayName.length() == 0) displayName = safe(user.getDisplayName());
                    if (displayName.length() == 0) displayName = "કારીગર";
                    Map<String, Object> worker = new HashMap<>();
                    worker.put("companyId", companyId);
                    worker.put("companyName", companyName);
                    worker.put("companyCode", code);
                    worker.put("name", displayName);
                    worker.put("firstName", first);
                    worker.put("lastName", last);
                    worker.put("phone", safe(profile.getString("phone")));
                    worker.put("birthday", safe(profile.getString("birthday")));
                    worker.put("totalDiamonds", 0L);
                    worker.put("active", false);
                    worker.put("mode", "both");
                    worker.put("removed", false);
                    database.collection("workers").document(user.getUid()).set(worker)
                        .addOnSuccessListener(v -> {
                            workerJoinButton.setEnabled(true);
                            currentCompanyName = companyName;
                            showWorkerPending(companyName);
                        })
                        .addOnFailureListener(e -> {
                            workerJoinButton.setEnabled(true);
                            workerJoinStatus.setText("રિક્વેસ્ટ મોકલી શકાયી નથી. ફરી પ્રયાસ કરો.");
                        });
                }).addOnFailureListener(e -> {
                    workerJoinButton.setEnabled(true);
                    workerJoinStatus.setText("કારીગરની માહિતી મળી નથી.");
                });
            })
            .addOnFailureListener(e -> {
                workerJoinButton.setEnabled(true);
                workerJoinStatus.setText("રિક્વેસ્ટ મોકલી શકાયી નથી. ફરી પ્રયાસ કરો.");
            });
    }

    private void showWorkerPending(String companyName) {
        hideAll();
        pending.setVisibility(View.VISIBLE);
        String shownName = companyName == null || companyName.length() == 0 ? "તમારી કંપની" : companyName;
        pendingInfo.setText(shownName + "\n\nરિક્વેસ્ટ મોકલાઈ ગઈ છે.\nશેઠ મંજૂર કરશે પછી એપ ખુલી જશે.");
    }

    private void grantRole(FirebaseUser user, String role, String mode) {
        currentRole = role;
        currentMode = mode;
        hideAll();
        page.setVisibility(View.VISIBLE);
        if (!user.getUid().equals(loadedUid)) {
            loadedUid = user.getUid();
            page.loadUrl("file:///android_asset/app.html?uid=" + Uri.encode(loadedUid));
        } else {
            updateAccountLabel();
            updateRoleInPage();
        }
    }

    private void updateRoleInPage() {
        if (currentRole == null) return;
        String js = "window.mbRole && window.mbRole(" +
            org.json.JSONObject.quote(currentRole) + "," + org.json.JSONObject.quote(currentMode) + ");";
        if ("boss".equals(currentRole)) {
            js += "var p=document.getElementById('bossWorkerPanel');if(p)p.style.display='none';";
        }
        page.evaluateJavascript(js, null);
    }

    private void updateAccountLabel() {
        FirebaseUser user = auth.getCurrentUser();
        if (user == null || currentRole == null) return;
        String name = user.getDisplayName() == null ? user.getEmail() : user.getDisplayName();
        page.evaluateJavascript("window.mbAccount && window.mbAccount(" +
            org.json.JSONObject.quote(name == null ? "Google એકાઉન્ટ" : name) + ")", null);
    }

    private void signIn() {
        if (signingIn) return;
        signingIn = true;
        loginButton.setEnabled(false);
        loginStatus.setText("Google લોગીન ખૂલી રહ્યું છે…");
        GetGoogleIdOption option = new GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(getString(R.string.default_web_client_id))
            .build();
        GetCredentialRequest request = new GetCredentialRequest.Builder()
            .addCredentialOption(option).build();
        credentials.getCredentialAsync(this, request, new CancellationSignal(),
            Executors.newSingleThreadExecutor(), new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override public void onResult(GetCredentialResponse response) {
                    Credential credential = response.getCredential();
                    if (!(credential instanceof CustomCredential) ||
                        !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
                        runOnUiThread(() -> signInError("Google એકાઉન્ટ પસંદ થઈ શક્યું નથી"));
                        return;
                    }
                    try {
                        String token = GoogleIdTokenCredential.createFrom(credential.getData()).getIdToken();
                        runOnUiThread(() -> auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null))
                            .addOnCompleteListener(MainActivity.this, task -> {
                                signingIn = false;
                                loginButton.setEnabled(true);
                                if (task.isSuccessful()) showAuthState();
                                else signInError("લોગીન નિષ્ફળ ગયું. ફરી પ્રયાસ કરો.");
                            }));
                    } catch (Exception e) {
                        runOnUiThread(() -> signInError("Google લોગીન પૂર્ણ થઈ શક્યું નથી"));
                    }
                }
                @Override public void onError(GetCredentialException e) {
                    runOnUiThread(() -> signInError("લોગીન રદ થયું અથવા Google એકાઉન્ટ મળ્યું નથી"));
                }
            });
    }

    private void signInError(String message) {
        signingIn = false;
        loginButton.setEnabled(true);
        loginStatus.setText(message);
    }

    private void signOut() {
        clearWorkerListener();
        clearBossWorkersListener();
        bossAppOpened = false;
        currentCompanyName = null;
        currentCompanyCode = null;
        currentRole = null;
        currentMode = null;
        auth.signOut();
        showAuthState();
    }

    private void clearWorkerListener() {
        if (workerListener != null) {
            workerListener.remove();
            workerListener = null;
        }
        watchingUid = null;
    }

    private void clearBossWorkersListener() {
        if (bossWorkersListener != null) {
            bossWorkersListener.remove();
            bossWorkersListener = null;
        }
    }

    private void hideAll() {
        page.setVisibility(View.GONE);
        login.setVisibility(View.GONE);
        if (roleChoice != null) roleChoice.setVisibility(View.GONE);
        Object workerProfileTag = workerProfile == null ? null : workerProfile.getTag();
        if (workerProfileTag instanceof ScrollView) ((ScrollView) workerProfileTag).setVisibility(View.GONE);
        setBossVisible(false);
        workerJoin.setVisibility(View.GONE);
        pending.setVisibility(View.GONE);
    }

    private void setBossVisible(boolean visible) {
        Object tag = bossScreen.getTag();
        if (tag instanceof ScrollView) ((ScrollView) tag).setVisibility(visible ? View.VISIBLE : View.GONE);
    }

    private LinearLayout baseScreen() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(dp(24), dp(30), dp(24), dp(30));
        layout.setBackgroundColor(0xfff3f5f9);
        return layout;
    }

    private TextView titleText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(25);
        view.setTextColor(0xff17243a);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private TextView sectionText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(18);
        view.setTextColor(0xff17243a);
        view.setTypeface(Typeface.DEFAULT_BOLD);
        return view;
    }

    private TextView bodyText(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(15);
        view.setTextColor(0xff536073);
        return view;
    }

    private EditText input(String hint) {
        EditText view = new EditText(this);
        view.setHint(hint);
        view.setSingleLine(true);
        view.setTextColor(0xff17243a);
        view.setHintTextColor(0xff8a95a5);
        view.setPadding(dp(12), dp(12), dp(12), dp(12));
        return view;
    }

    private Button primaryButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(0xffffffff);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setBackgroundTintList(ColorStateList.valueOf(0xffa80d32));
        LinearLayout.LayoutParams p = fullWrap();
        p.topMargin = dp(12);
        button.setLayoutParams(p);
        return button;
    }

    private Button secondaryButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(0xff9b1e3b);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setBackgroundTintList(ColorStateList.valueOf(0xffffffff));
        LinearLayout.LayoutParams p = fullWrap();
        p.topMargin = dp(10);
        button.setLayoutParams(p);
        return button;
    }

    private LinearLayout.LayoutParams fullWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == FILE_CHOOSE && chooserCallback != null) {
            chooserCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            chooserCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (page.getVisibility() == View.VISIBLE && page.canGoBack()) page.goBack();
        else super.onBackPressed();
    }

    private class Bridge {
        @JavascriptInterface public void signOut() {
            runOnUiThread(() -> MainActivity.this.signOut());
        }

        @JavascriptInterface public void approveWorker(String uid, String name, String mode) {
            runOnUiThread(() -> {
                FirebaseUser user = auth.getCurrentUser();
                if (user == null || !"boss".equals(currentRole)
                    || !uid.matches("[A-Za-z0-9]{20,128}")) return;
                Map<String,Object> worker = new HashMap<>();
                worker.put("mode", "both");
                worker.put("active", true);
                worker.put("removed", false);
                worker.put("name", name.length() > 80 ? name.substring(0, 80) : name);
                database.collection("workers").document(uid).set(worker, com.google.firebase.firestore.SetOptions.merge())
                    .addOnSuccessListener(v -> page.evaluateJavascript("alert('કારીગર મંજૂર થયો')", null))
                    .addOnFailureListener(e -> page.evaluateJavascript("alert('મંજૂરી સેવ થઈ નથી')", null));
            });
        }

        @JavascriptInterface public void syncWorkerTotalDiamonds(int total) {
            runOnUiThread(() -> {
                FirebaseUser user = auth.getCurrentUser();
                if (user == null || !"worker".equals(currentRole) || total < 0) return;
                Map<String,Object> update = new HashMap<>();
                update.put("totalDiamonds", total);
                database.collection("workers").document(user.getUid()).update(update);
            });
        }

        @JavascriptInterface public void printPdf(String html) {
            runOnUiThread(() -> {
                if (printing != null) {
                    printing.destroy();
                    printing = null;
                }
                printing = new WebView(MainActivity.this);
                printing.getSettings().setDefaultTextEncodingName("UTF-8");
                printing.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager manager = (PrintManager) getSystemService(PRINT_SERVICE);
                        manager.print("MB-Diamond-Diary-Report",
                            view.createPrintDocumentAdapter("MB-Diamond-Diary-Report"),
                            new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                    }
                });
                printing.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }
    }

    @Override protected void onDestroy() {
        clearWorkerListener();
        clearBossWorkersListener();
        if (printing != null) printing.destroy();
        if (page != null) page.destroy();
        super.onDestroy();
    }
}
