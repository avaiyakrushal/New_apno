MB Diamond Diary v2.0.4 — v2.0.2 stable login base update

Implemented in source:
- Google-only login retained from v2.0.2.
- First-login role selection: Worker / Boss.
- Worker profile: first name, surname, mobile, birthday.
- Worker joins via boss company code.
- Boss worker list shows name, mobile, birthday, worker-entered total diamonds.
- Boss can approve worker as Diamond or Hours, mark inactive, or remove.
- Worker total diamonds syncs from the worker diary to Firestore.
- Hours entry keeps withdrawal field and saves withdrawal together.
- Hours monthly report shows withdrawal column.
- Diamond monthly report keeps A-G in one horizontal date table.
- Settings keeps editable A-G diamond rates and fixed hourly rate.
- Existing diamond/hour/expense/salary calculations remain based on the v2.0.2 app logic.

Build note:
This package is source. A proper Android/Gradle build is required for an installable APK.
